#pragma once
class Subject
{
};

