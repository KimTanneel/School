<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./style2.css">
</head>
<body>
    <h1 style="text-align:center">Trang 2</h1>
    <div class="label">Trang chủ
    </div>
    <div class="listoptions">
        <div  class="options">
            <a href="./login.php" target="center">Login</a>
        </div>
        <div class="options">
            <a href="./timkiem.php"target="center">Tìm kiếm NV</a>
        </div>
        <div class="options">
            <a href="./xemthongtinPB.php"target="center">Xem thông tin PB</a>
        </div>
        <div class="options">
            <a href="./xoathongtinNV.php"target="center">Xóa thông tin NV</a>
        </div>
        <div class="options">
            <a href="./themthongtinNV.php"target="center">Thêm Nhân Viên</a>
        </div>
    </div>
        
</body>
</html>