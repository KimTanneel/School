<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="xulithemthongtinNV.php">
    <table>
        <tr>
            <th>IDNV</th>
            <th>Họ Tên</th>
            <th>IDPB</th>
            <th>Địa chỉ</th>
        </tr>
        <tr>
            <td>
                <input readonly type="text" name="idnv" value="automatic">
            </td>
            <td>
                <input type="text" name="hoten">
            </td>
            <td>
                <input type="text" name="idpb">
            </td>
            <td>
                <input type="text" name="diachi">
            </td>
            
        </tr>
        
    </table>    
    <input type="submit" value="add">
    </form>
   
</body>
</html>